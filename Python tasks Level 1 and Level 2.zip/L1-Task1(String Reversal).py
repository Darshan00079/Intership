string=input("Enter the string: ")
rev_string=string[::-1]
print("Reversed string :",rev_string)